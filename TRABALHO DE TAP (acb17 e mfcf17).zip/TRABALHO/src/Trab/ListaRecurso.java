package Trab;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;

public class ListaRecurso implements Serializable{ 
	private Nodo comeco;
	private int size = 0;
	public ListaRecurso(){}

  	private class Nodo implements Serializable{
    	String sala;
    	ArrayList <String> lista;
    	int posSala;	//código (posição) do prédio na lista
    	Nodo next;
    	public Nodo(){}
  	}

 	public void InsereRecurso(String sala, int num_recursos)
 	{
    	Nodo no = new Nodo();
    	no.lista = new ArrayList<String>();
    	Scanner teclado = new Scanner(System.in);
    	String nome;
    	int i;
    	no.sala = sala;
    	
    	for (i = 1; i <= num_recursos; ++i)
    	{
    		System.out.printf("\tDigite o recurso %d: ", i);
    		nome = teclado.nextLine();
    		no.lista.add(nome);
    	}
    	
    	i = 1;
    	if(this.size != 0){
      		Nodo aux = this.comeco;
      		while ((i < size) && (aux.next != null)) {
        		aux = aux.next;
        		i++; 
      		}
      		no.next = aux.next;
      		aux.next = no;
      		this.size++;
      		i++;
      		no.posSala = i;
    	}
    	else{    //então não tem salas cadastradas ainda
      		this.comeco = no;
      		no.next = null;
      		no.posSala = i;
      		this.size++;
    	}
  	} //PRONTO

  	public void mostraListaRecurso(ListaRecurso listaR)
  	{
    	Nodo aux = this.comeco;
    	Iterator <String> it;
    	if(this.size == 0){
    		System.out.println("Nenhum recurso foi cadastrado ainda");
    	}
    	else
    	{
	   		for(int i = 0; i<this.size;i++){
	      		System.out.printf("\tSala: %s, código: %d\n",aux.sala, aux.posSala);
	      		it = aux.lista.iterator();
	      		int count = 1;
	      		while(it.hasNext()) 
	      		{
	      			System.out.printf("\tRecurso: %s, posição: %d\n ", it.next(), count);
	      			count ++;
	      		}
	      		System.out.printf("\n"); 
	      		aux = aux.next;
	    	}
    	}
 	} //PRONTO

 	public boolean vazia(ListaRecurso listaR)
 	{
        if(this.size == 0)
            return true;
        return false;
    } //PRONTO

    public void removeRecurso(int remove_sala, int remove_recurso)
    {
    	Nodo aux =  this.comeco;
    	while((aux.posSala != remove_sala) && (aux.next != null)){
    		aux = aux.next;
    	}
    	aux.lista.remove(remove_recurso - 1);
    	
    	//se não tem recursos cadastrados para aquela sala, remove a própria sala
    	if (aux.lista.size() == 0)
    	{
    		 aux =  this.comeco;
             Nodo prev = new Nodo();
             int i = 1;
             while((i!= remove_sala) && (aux.next != null)){
                 prev = aux;
                 aux = aux.next;
                 i++;
             }
             prev.next = aux.next;
             this.size --;
             for(i=remove_sala; i<=this.size; i++){
                 aux = aux.next;
                 aux.posSala = i;
             }            
    	}
    } //

    public void grava(ListaRecurso listaR)
    {
    	Nodo aux = this.comeco;
    	Iterator <String> it;
    	try
    	{
    		FileOutputStream arq = new FileOutputStream ("recursos.dat");
    		ObjectOutputStream obj = new ObjectOutputStream (arq);
        	DataOutputStream gravarArq = new DataOutputStream (arq);
        	
        	//imprime a quantidade de salas cadastradas
        	gravarArq.writeInt(this.size);
        	
    		for(int i = 0; i < this.size; i++)
    		{
    			it = aux.lista.iterator();
    			gravarArq.writeUTF(aux.sala);
        		
        		//imprime a quantidade de recursos cadastrados para aquela sala
        		int contador = aux.lista.size();
        		gravarArq.writeInt(contador);
        		
        		while (it.hasNext())
        		{
        			gravarArq.writeUTF(it.next());
        		}
        		
        		aux = aux.next;
    		}
    		System.out.println("\tGravação de recursos realizada com sucesso!");
    		arq.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("\tOcorreu um erro durante a gravação do arquivo! " + ex.getMessage());
    	}
    } //PRONTO

    public void leitura(ListaRecurso listaR)
    {
    	int contador_sala, contador_recurso, posicao;
    	String sala, recurso;
    	
    	try
    	{
    		FileInputStream arq = new FileInputStream ("recursos.dat");
    		ObjectInputStream obj = new ObjectInputStream (arq);
    		DataInputStream lerArq = new DataInputStream(arq);
    		
    		//le a quantidade de salas cadastradas
    		contador_sala = lerArq.readInt();
    		
    		
    		for (int i = 0; i < contador_sala; i++)
    		{
    			sala = lerArq.readUTF();
    			//System.out.printf("sala: %s \n", sala);
    			
    			contador_recurso = lerArq.readInt();
    			//System.out.printf("Número de recursos cadastrados para essa sala: %d\n", contador_recurso);
    			
    			for (int j = 0; j < contador_recurso; ++j)
    			{
    				recurso = lerArq.readUTF();
    				//System.out.printf("recurso: %s\n", recurso);
    				InsereRecursoArquivo (i, sala, recurso, listaR);
    			}
    		}
    		
    		System.out.println("\tLeitura de recursos concluída com sucesso!");
    		arq.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("\tOcorreu um erro durante a leitura do arquivo! " + ex.getMessage());
    	}
    } //PRONTO
    
    public void InsereRecursoArquivo(int posicao, String sala, String recurso, ListaRecurso listaR)
    {
    	if (this.size == 0)
    	{
    		Nodo no = new Nodo ();
    		no.lista = new ArrayList<String>();
    		no.lista.add(recurso);
    		no.sala = sala;
    		this.comeco = no;
    		no.next = null;
    		no.posSala = 1;
      		this.size ++;
    	}
    	else //se não estiver vazia
    	{
    		int i = 0;
    		Nodo posterior = this.comeco;
    		Nodo anterior = null;
    		while (i < posicao)
    		{
    			anterior = posterior;
    			posterior = posterior.next;
    			if (posterior == null)
    			{
    				Nodo no = new Nodo ();
    				anterior.next = no;
    				no.next = null;
    				
    	    		no.lista = new ArrayList<String>();
    	    		no.sala = sala;
    	    		no.posSala = i + 2;
    	    		this.size ++;
    	    		
    	    		posterior = no;
    			}
    			++i;
    		}
    		posterior.lista.add(recurso);
    	}
  	} //PRONTO
    
}