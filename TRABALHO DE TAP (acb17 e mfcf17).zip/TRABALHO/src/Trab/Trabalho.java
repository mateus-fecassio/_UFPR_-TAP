package Trab;
import Trab.ListaUsuario;
import Trab.ListaRecurso;
import Trab.ListaAgendamentos;
import java.io.*;
import java.util.Scanner;


public  class Trabalho
{
//-------------------------------------LIMPA A TELA DO CONSOLE-------------------------------------------	
	public static void LimpaTela()
	{
    	for (int p = 0; p < 200; ++p)
    		System.out.print("\r\n");
	}
//-----------------------------------------------MENU-----------------------------------------------------
    public static int menu(){
        int menu;
        Scanner entrada = new Scanner(System.in);       //entrada define-se entradas de stdin
        System.out.printf("\n\t========================== MENU ==========================\n");
        System.out.println("\t1)PARA CADASTRAR USUÁRIO DIGITE 1");
        System.out.println("\t2)PARA CADASTRAR RECURSO DIGITE 2");
        System.out.println("\t3)PARA AGENDAMENTO DE RECURSO DIGITE 3");
        System.out.println("\t4)PARA LISTAR OS USUÁRIOS DIGITE 4");
        System.out.println("\t5)PARA LISTAR OS RECURSO DIGITE 5");
        System.out.println("\t6)PARA LISTAR OS AGENDAMENTOS DIGITE 6");
        System.out.println("\t7)PARA REMOVER UM USUÁRIO DIGITE 7");
        System.out.println("\t8)PARA REMOVER UM RECURSO DIGITE 8");
        System.out.println("\t9)PARA REMOVER AGENDAMENTO DIGITE 9");
        System.out.println("\t10)PARA ENCERRAR DIGITE 10");
        System.out.printf("\t============================================================\n");

        menu = entrada.nextInt();
        entrada.nextLine(); //ler o \n para não atrapalhar o buffer
        return menu;
    }

    public static void main(String[] args){
        ListaUsuario listaU = new ListaUsuario();
        ListaRecurso listaR = new ListaRecurso();
        ListaAgendamentos listaA = new ListaAgendamentos();

        Scanner entrada = new Scanner(System.in);		//entrada define-se entradas de stdin
        String nome, email, telefone, sala, data, recurso;
        int menu, num_recursos, verifica, hora = 0, minuto = 0, disponibilidade;
        boolean condicao = true;
        
        System.out.println("\t==========================INÍCIO DA APLICAÇÃO==========================");
        System.out.println("\tO que você deseja fazer?");
        System.out.println("\tAbrir dados do arquivo [OPÇÃO 1]");
        System.out.println("\tComeçar uma nova aplicação [OPÇÃO 2]");
        menu = entrada.nextInt();
        entrada.nextLine();
        
        if (menu == 1)
        {
        	System.out.println("\tLendo do arquivo...");
        	listaU.leitura(listaU);
        	listaR.leitura(listaR);
        	listaA.leitura(listaA);
        }
        else
        	if (menu != 2) 
        	{
        		System.out.println("\tPor favor, digite uma opção válida!");
        	}
        System.out.println("\t=======================================================================");
        //LimpaTela();
        while (condicao == true){
        	menu = menu(); 
//--------------------------------------------CADASTRO DE USUÁRIO - OK-----------------------------------------------
            if(menu == 1){
            	LimpaTela();
            	System.out.println("\t==========================Cadastro de usuário==========================");
                System.out.println("\tDigite seus dados: ");
                System.out.printf("\tNome: ");
   	            nome = entrada.nextLine();			//acessando o método da classe e inserindo o nome
                System.out.printf("\tEmail: ");		
                email = entrada.nextLine();			//insere o email
                System.out.printf("\tTelefone: ");
                telefone = entrada.nextLine();		//insere o telefone
                System.out.println("\t=======================================================================");
                listaU.InsereUsuario(nome,email,telefone);
                LimpaTela();
            }
            else
//-----------------------------------------CADASTRO DE RECURSO - OK---------------------------------------------------
                if(menu == 2){
                	LimpaTela();
                	System.out.println("\t==========================Cadastro de recurso==========================");
                    System.out.printf("\tDigite a sala dos recursos a serem cadastrados [no formato PA01]: ");    
                    sala = entrada.nextLine();  //acessando o método da classe e inserindo a sala
                    System.out.printf("\tQuantos recursos você gostaria de cadastrar para essa sala? ");
                    num_recursos = entrada.nextInt();
                    entrada.nextLine();
                    listaR.InsereRecurso(sala, num_recursos); 
                    System.out.println("\t=======================================================================");
                    LimpaTela();
                }else

//-------------------------------------------AGENDAMENTO DE RECURSO - OK-------------------------------------------------
                    if (menu == 3){
                    	LimpaTela();
                    	int disposicao;
                        int valida_horario = 0;
                        System.out.println("\t=============================Agendamento de recurso=============================");
                        if(listaR.vazia(listaR))
                        {
                            System.out.println("\tNão é possível agendar recurso pois não há recursos cadastrados.");
                        }else //tem recursos cadastrados
                        {
                        	System.out.printf("\tVocê está cadastrado na aplicação? [SIM = 1] [NÃO = 0] ");
                        	verifica = entrada.nextInt();
                        	entrada.nextLine(); 
                        	if (verifica == 0 )
                        	{
                        		System.out.printf("\tPara reservar um recurso você precisa estar cadastrada na aplicação! \n");
                        		System.out.printf("\tPor favor, faça o cadastro.\n");
                        	}
                        	else if (verifica == 1)
                        	{
                        		disponibilidade = 0;
                        		System.out.printf("\n");
                        		System.out.println("\tLista de usuários cadastrados:");
                        		listaU.mostraNomesUsuario(listaU);
                        		System.out.printf("\n");
                        		System.out.printf("\tQuem é você dessa lista? ");
                        		nome = entrada.nextLine();
                        		System.out.printf("\n");
                        		System.out.println("\tLista de recursos cadastrados:");
                        		listaR.mostraListaRecurso(listaR);
                        		System.out.printf("\tQual sala esse recurso está localizado? ");
                        		sala = entrada.nextLine();
                        		System.out.printf("\tQual o recurso dessa sala que você gostaria de reservar? ");
                        		recurso = entrada.nextLine();
                        		
                        		while (disponibilidade == 0) //
                        		{
	                        		System.out.printf("\tInforme a data [DD/MM/AAAA]: ");
	                        		data = entrada.nextLine();
	                        		while (valida_horario == 0)
	                        		{
	                        			System.out.printf("\tInforme somente a hora [07~22]: ");
		                        		hora = entrada.nextInt();
		                        		entrada.nextLine();
		                        		System.out.printf("\tInforme o minuto [00~59]: ");
		                        		minuto = entrada.nextInt();
		                        		entrada.nextLine();
		                        		valida_horario = listaA.verifica_horario (hora, minuto);
	                        		}
	                        		disponibilidade = listaA.InsereAgendamento (nome, sala, recurso, data, hora, minuto);
	                        		if (disponibilidade == 0)
	                        		{
	                        			System.out.printf("\tDeseja continuar o agendamento para esse prédio? [SIM = 0] [NÃO = 1]: ");
		                        		disponibilidade = entrada.nextInt();
		                        		entrada.nextLine();
	                        		}
	                        	}
                        	}
                        	else if (verifica != 0 && verifica != 1)
                        	{
                        		System.out.println("Digite uma opção válida!\n");
                        	}
                        	System.out.println("\t========================================================================");
                        	LimpaTela();
                        }
                    }else 

//-----------------------------------------------LISTA DE USUÁRIO - OK--------------------------------------------------
                        if(menu == 4){  
                        	LimpaTela();
                        	System.out.println("\t==========================LISTA DE USUÁRIOS==========================");
                            if(listaU.vazia(listaU)){
                                System.out.println("\tNão há usuários cadastrados ainda.");
                            }else
                                listaU.mostraListaUsuario(listaU);
                            System.out.println("\t=====================================================================");
                        }else

//---------------------------------------------LISTA DE RECURSO - OK-----------------------------------------------------
                            if(menu == 5){  
                            	LimpaTela();
                            	System.out.println("\t==========================LISTA DE RECURSOS==========================");
                                if(listaR.vazia(listaR)){
                                    System.out.println("\tNão há recursos cadastrados ainda.");
                                }else
                                    listaR.mostraListaRecurso(listaR);
                                System.out.println("\t=====================================================================");
                            }else

//------------------------------------------------LISTAS DE AGENDAMENTO - OK-------------------------------------------------
                                if(menu == 6){
                                	LimpaTela();
                                    System.out.println("\t==========================LISTA DE AGENDAMENTOS==========================");
                                    if(listaA.vazia(listaA)){
                                        System.out.println("\tNão há agendamentos cadastrados ainda.");
                                    }else
                                        listaA.mostraListaAgendamento(listaA);
                                    System.out.println("\t=========================================================================");
                                }else

//--------------------------------------------------REMOVE USUÁRIO - OK---------------------------------------------------
                                    if (menu == 7){
                                    	LimpaTela();
                                        System.out.println("\t==========================REMOVER USUÁRIO==========================");
                                        if(listaU.vazia(listaU)){   
                                            System.out.println("\tNão há usuários cadastrados ainda, não é possível remover.");
                                        }else{
                                            System.out.println("\tPara remover um usuário é necessário passar sua posição na lista.");
                                            listaU.mostraListaUsuario(listaU);
                                            System.out.printf("\tDigite a posição do usuário que você deseja remover: ");
                                            int remove = entrada.nextInt();
                                            entrada.nextLine();
                                            listaU.removeUsuario(remove);
                                        }
                                        System.out.println("\t===================================================================");
                                        //LimpaTela();
                                    }else

//---------------------------------------------------------REMOVE RECURSO - OK---------------------------------------------------------------
                                        if(menu == 8){ 
                                        	LimpaTela();
                                        	System.out.println("\t=================================REMOVER RECURSO=================================");
                                            if(listaR.vazia(listaR)){
                                                System.out.println("\tNão há recursos cadastrados ainda para nenhuma sala, não é possível remover.");   
                                            }else{
                                                System.out.println("\tPara remover recurso é necessário passar sua posição na lista.");
                                                listaR.mostraListaRecurso(listaR);
                                                System.out.printf("\tDigite o código da SALA do recurso que você deseja remover: ");
                                                int remove_sala = entrada.nextInt();
                                                entrada.nextLine();
                                                System.out.printf("\tDigite a POSIÇÃO do RECURSO que você deseja remover: ");
                                                int remove_recurso = entrada.nextInt();
                                                entrada.nextLine();
                                                listaR.removeRecurso(remove_sala, remove_recurso);
                                            }
                                            System.out.println("\t=================================================================================");
                                            //LimpaTela();
                                        }else

//---------------------------------------------------REMOVE AGENDAMENTO - OK-------------------------------------------------------
                                            if(menu == 9){
                                            	LimpaTela();
                                            	System.out.println("\t==========================REMOVER AGENDAMENTO==========================");
                                                if(listaA.vazia(listaA)){   
                                                    System.out.println("\tNão há agendamentos cadastrados ainda, não é possível remover.");
                                                }else{
                                                    System.out.println("\tPara remover um agendamento é necessário passar sua posição na lista");
                                                    listaA.mostraListaAgendamento(listaA);
                                                    System.out.printf("\tDigite a posição do agendamento que você deseja remover: ");
                                                    int remove = entrada.nextInt();
                                                    entrada.nextLine();
                                                    listaA.removeAgendamento(remove);
                                                }
                                                System.out.println("\t=======================================================================");
                                                //LimpaTela();
                                            } else
//---------------------------------------------------ENCERRAMENTO DA APLICAÇÃO - OK-------------------------------------------------------
                                            	if(menu == 10){
                                            		LimpaTela();
                                            		System.out.println("\t==========================ENCERRAMENTO DA APLICAÇÃO==========================");
                                            		if (!listaU.vazia(listaU))
                                            			listaU.grava(listaU);
                                            		if (!listaR.vazia(listaR))
                                            			listaR.grava(listaR);
                                            		if (!listaA.vazia(listaA))
                                            			listaA.grava(listaA);
                                            		System.out.printf("\n");
                                            		System.out.println("\tAté breve!");
                                            		System.out.println("\t=============================================================================");
                                            		condicao = false;
                                            	}
        }//fim while
    }
}