package Trab;
import java.io.*;
import java.io.Serializable;

public class ListaUsuario implements Serializable{
	private Nodo comeco;
	private int size = 0;
	public ListaUsuario(){}	//auto referenciar

	private class Nodo implements Serializable{
		String nome;
		String email;
		String telefone;
		int posUsuario;	//posicao da lista
		Nodo next;
		public Nodo(){}	//auto referenciar
	}

	
    public void InsereUsuario(String nome, String email, String telefone)
    {
    	Nodo no = new Nodo();
        no.nome = nome;
        no.email = email;
        no.telefone = telefone;
        int i = 1;
        if(this.size != 0){	//então ja tem elementos na lista
            Nodo aux = this.comeco;
            while ((i < size) && (aux.next != null)){
                aux = aux.next;
                i++;
            }
            no.next = aux.next;
            aux.next = no;
            this.size++;
            i++;
            no.posUsuario = i;
        }
        else{		//então não tem usuarios cadastrados ainda
           this.comeco = no;
           no.next = null;
           no.posUsuario = i;
           this.size++;
        }
    } //PRONTO

    public void mostraListaUsuario(ListaUsuario listaU)
    {
    	Nodo aux = this.comeco;  
    	for(int i = 0; i<this.size;i++){
    		System.out.printf("\tPosição : %d\n \tNome: %s\n \tEmail: %s\n \tTelefone: %s\n\n",aux.posUsuario,aux.nome,aux.email,aux.telefone);
            aux = aux.next;
        }
    } //PRONTO
    
    public void mostraNomesUsuario(ListaUsuario listaU)
    {
    	Nodo aux = this.comeco;  
    	for(int i = 0; i<this.size;i++){
    		System.out.printf("\tNome: %s\n",aux.nome);
            aux = aux.next;
        }
    } //PRONTO

    public boolean vazia(ListaUsuario listaU)
    {
        if(this.size == 0)
            return true;
        return false;
    } //PRONTO

    public void removeUsuario(int posUsuario)
    {
        if(this.size == 0){
            System.out.println("Não há nenhum usuário cadastrado ainda, não é possível remover.");
        }
        else{
            Nodo aux =  this.comeco;
            Nodo prev = new Nodo();
            int i = 1;
            while((i!= posUsuario) && (aux.next != null)){
                prev = aux;
                aux = aux.next;
                i++;
            }
            prev.next = aux.next;
            this.size --;
            for(i=posUsuario; i<=this.size; i++){
                aux = aux.next;
                aux.posUsuario = i;
            }            
        }// fim else
    } //PRONTO
    
    public void grava(ListaUsuario listaU)
    {
    	Nodo aux = this.comeco;  
    	try
    	{
    		FileOutputStream arq = new FileOutputStream ("usuarios.dat");
    		ObjectOutputStream obj = new ObjectOutputStream (arq);
        	DataOutputStream gravarArq = new DataOutputStream (arq);
        	
        	gravarArq.writeInt(this.size);
        	
    		for(int i = 0; i < this.size; i++)
    		{
        		obj.writeObject(aux);
        		obj.flush();
                aux = aux.next;
    		}
    		System.out.println("\tGravação de usuários realizada com sucesso!");
    		arq.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("\tOcorreu um erro durante a gravação do arquivo! " + ex.getMessage());
    	}
    } //PRONTO 

    public void leitura(ListaUsuario listaU)
    { 
    	try
    	{
    		FileInputStream arq = new FileInputStream ("usuarios.dat");
    		ObjectInputStream obj = new ObjectInputStream (arq);
    		DataInputStream lerArq = new DataInputStream(arq);
    		
    		int contador = lerArq.readInt();
    		//System.out.printf("Foram cadastrados %d usuários \n", contador);
    		
    		
    		for (int i = 0; i < contador; i++)
    		{
    			Nodo usuario = (Nodo) obj.readObject();
    			InsereUsuario (usuario.nome, usuario.email, usuario.telefone);
    		}
    		System.out.println("\tLeitura de de usuários concluída com sucesso!");
    		arq.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("\tOcorreu um erro durante a leitura do arquivo! " + ex.getMessage());
    	}
    } //PRONTO
}