package Trab;
import java.io.*;

public class ListaAgendamentos implements Serializable
{
	private Nodo comeco;
	private int size = 0;
	public ListaAgendamentos(){}

  	private class Nodo implements Serializable
  	{
    	String usuario;
    	String sala;
    	String recurso;
    	String data;
    	int hora;
    	int minuto;
    	int identificacao;
    	Nodo next;
    	public Nodo(){}
  	}
  	
  	public  int InsereAgendamento(String nome, String sala, String recurso, String data, int hora, int minuto)
  	{
  		Nodo no = new Nodo();
        no.usuario = nome;
        no.sala = sala;
        no.recurso = recurso;
        no.data = data;
        no.hora = hora;
        no.minuto = minuto;
        int i = 0;
        int disponibilidade;
        
        disponibilidade = verifica_horario(hora, minuto);
        //0: assume que NÃO existe possibilidade de horário
        //1: assume que existe possibilidade de horário
       
        if(this.size != 0)//então ja tem elementos na lista
        {	
            Nodo aux = this.comeco;
            Nodo apontador = null;
            while ((i < size) && (disponibilidade == 1))
            {
                apontador = aux;
            	if (no.sala.equals(aux.sala))
                {
                	//if (no.recurso.equals(aux.recurso))
                	//{
                		if (no.data.equals(aux.data))
                		{
                			disponibilidade = compara_horario (no.hora, no.minuto, aux.hora, aux.minuto);
                		}
                	//}
                }
            	aux = aux.next;
                i++;
            }
            if (disponibilidade == 1)
            {
                no.next = apontador.next;
                apontador.next = no;
                this.size++;
                i++;
                no.identificacao = i;
            }
            else
            	return 0;
        }
        else //primeira inserção
        {
           this.comeco = no;
           no.next = null;
           no.identificacao = i+1;
           this.size++;
        }
  		
  		return 1;
  	} //PRONTO
  	
  	public int verifica_horario(int hR, int mR)
  	{
  		if (hR < 7 || hR > 22)
  		{
  			System.out.printf("\tO intervalo da hora tem que estar entre 07h e 22h\n");
  			return 0;
  		}
  		
  		if (mR < 0 || hR > 59)
  		{
  			System.out.printf("\tO intervalo dos minutos tem que estar entre 00 e 59\n");
  			return 0;
  		}
  		
  		return 1; //caso esse horário esteja dentro do padrão
  	}//PRONTO
  	
  	public int compara_horario(int hR, int mR, int hora, int minuto)
  	{
  		if (hR == hora)
  		{
  			System.out.printf("Esse horário não está disponível. Por favor, selecione outro horário.\n");
  			return 0;
  		}
  		
  		
  		//checa por um horário escolhido duas horas a menos ou duas horas a mais do horário que coincide a data
  		if (hR < hora-2)
  		{
  			return 1;
  		}
  		else if (hR > hora+2)
  		{
  			return 1;
  		}
  		
  		
  		//checa se o horário escolhido difere em duas horas exatas, para mais ou para menos
  		if (hR == hora-2)
  		{
  			if (mR <= minuto)
  			{
  				return 1;
  			}
  			else
  			{
  				System.out.printf("\tOs minutos desse agendamento devem ser ajustados.\n");
  				System.out.printf("\tPor favor, escolha um minuto anterior à %d.\n", minuto);
  				return 0;
  			}
  		}
  		else if (hR == hora+2)
  		{
  			if (mR >= minuto)
  			{
  				return 1;
  			}
  			else
  			{
  				System.out.printf("\tOs minutos desse agendamento devem ser ajustados.\n");
  				System.out.printf("\tPor favor, escolha um minuto posterior à %d.\n", minuto);
  				return 0;
  			}
  		}
  		return 1;
  	} //PRONTO
  	
  	public void mostraListaAgendamento(ListaAgendamentos listaA)
  	{
    	Nodo aux = this.comeco;  
    	for(int i = 0; i<this.size;i++){
    		System.out.printf("\tPosição: %s\n ", aux.identificacao);
    		System.out.printf("\tUsuário: %s\n ", aux.usuario);
    		System.out.printf("\tSala: %s\n ", aux.sala);
    		System.out.printf("\tRecurso: %s\n ", aux.recurso);
    		System.out.printf("\tData: %s\n ", aux.data);
    		System.out.printf("\tHorário: %d:%d\n\n", aux.hora, aux.minuto);
    		
            aux = aux.next;
        }
  	} //PRONTO
  	
  	public boolean vazia(ListaAgendamentos listaA)
  	{
  		if(this.size == 0)
            return true;
        return false;
  	 } //PRONTO
  	 
  	public void removeAgendamento(int identificacao)
  	{
        if(this.size == 0){
            System.out.println("Não há nenhum agendamento cadastrado ainda, não é possível remover.");
        }
        else{
            Nodo aux =  this.comeco;
            Nodo prev = new Nodo();
            int i = 1;
            while((i!= identificacao) && (aux.next != null)){
                prev = aux;
                aux = aux.next;
                i++;
            }
            prev.next = aux.next;
            this.size --;
            for(i=identificacao; i<=this.size; i++){
                aux = aux.next;
                aux.identificacao = i;
            }            
        }// fim else
  	} //

    public void grava(ListaAgendamentos listaA)
    {
    	Nodo aux = this.comeco;  
    	try
    	{
    		FileOutputStream arq = new FileOutputStream ("agendamentos.dat");
    		ObjectOutputStream obj = new ObjectOutputStream (arq);
        	DataOutputStream gravarArq = new DataOutputStream (arq);
        	
        	gravarArq.writeInt(this.size);
        	
    		for(int i = 0; i < this.size; i++)
    		{
        		obj.writeObject(aux);
        		obj.flush();
                aux = aux.next;
    		}
    		System.out.println("\tGravação de agendamentos realizada com sucesso!");
    		arq.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("\tOcorreu um erro durante a gravação do arquivo! " + ex.getMessage());
    	}
    } //PRONTO 
   
    public void leitura(ListaAgendamentos listaA)
    {
    	try
    	{
    		FileInputStream arq = new FileInputStream ("agendamentos.dat");
    		ObjectInputStream obj = new ObjectInputStream (arq);
    		DataInputStream lerArq = new DataInputStream(arq);
    		
    		int contador = lerArq.readInt();
    		
    		for (int i = 0; i < contador; i++)
    		{
    			Nodo agend = (Nodo) obj.readObject();
    			InsereAgendamento (agend.usuario, agend.sala, agend.recurso, agend.data, agend.hora, agend.minuto);
    		}
    		System.out.println("\tLeitura de agendamentos concluída com sucesso!");
    		arq.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("\tOcorreu um erro durante a leitura do arquivo! " + ex.getMessage());
    	}
    } //PRONTO

}
